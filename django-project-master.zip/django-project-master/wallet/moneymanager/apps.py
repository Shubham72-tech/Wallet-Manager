from django.apps import AppConfig


class MoneymanagerConfig(AppConfig):
    name = 'moneymanager'
